package br.com.doistech.apicondomanagersaas.mapper;

import org.mapstruct.MapperConfig;

@MapperConfig(componentModel = "spring")
public interface GlobalMapperConfig {
}

